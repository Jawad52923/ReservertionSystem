<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\mycontroller;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::get('/index',[mycontroller::class,'index']);
Route::get('/Home',[mycontroller::class,'index4']);
Route::get('/Bus',[mycontroller::class,'index5']);
Route::get('/BusDetail',[mycontroller::class,'index7']);
Route::get('/SeatDetail',[mycontroller::class,'index8']);
// Route::get('/',[mycontroller::class,'index2']);

// Route::get('/',[mycontroller::class,'index3']);
Route::get('/login' ,[Mycontroller::class,'login']);
Route::get('/Busbook' ,[Mycontroller::class,'Busbook']);
Route::get('/Room' ,[Mycontroller::class,'Room']);
Route::get('/registration' ,[Mycontroller::class,'registration']);

//Route::get('/registration',[mycontroller::class,'registration']);
//Route::get('/', function () {
  //  return view('registration');
//});

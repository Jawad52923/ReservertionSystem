<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\registration;
use App\Models\Hotel;
use App\Models\Bus;

class mycontroller extends Controller
{

    // function index6(){
    //     return view('admin');
    // }
    function index7(){
        $data = Hotel::all();
        return view('admin',['data' => $data]);
    }
    function index8(){
        $data = Bus::all();
        return view('admin',['data' => $data]);
    }
    function index2(){
        return view('registration');
    }

    function index4(){
        return view('Home');
    }
    function index5(){
        return view('Bus');
    }
    function registration(Request $req){
        $FName = $req->get('FName');
        $LName = $req->get('LName');
        $Email = $req->get('Email');
        $Password = $req->get('Password');
        $User_type = $req->get('user_type');
        $reg = new registration();
        $reg->FName = $FName;
        $reg->LName = $LName;
        $reg->Email = $Email;
        $reg->Password = $Password;
        $reg->user_type=$User_type;
        $reg->save();
        return redirect('login');      
    }
    function login(Request $req){
        $Email = $req->get('Email');
        $Password = $req->get('Password');
        $result = count(registration::all()->where('Email',$Email)->where('Password',$Password)->where('user_type','==','Admin'));
        if($result > 0){
            return redirect('admin');
        }
         $Email = $req->get('Email');
        $Password = $req->get('Password');
        $result = count(registration::all()->where('Email',$Email)->where('Password',$Password)->where('user_type','==','user'));
        if($result > 0){
            return redirect('home');
        }
    
        else{
            echo 'Incorrect Email and Password';
        }
        
    }
    function index3(){
        return view('login');
    }

    function index(){

        return view('/index');
    }
    function Room(Request $req){
         $Name = $req->get('Name');
         $NIC = $req->get('NIC');
         $Mobile = $req->get('Mobile');
         $CheckInTime = $req->get('CheckInTime');
         $CheckOutTime = $req->get('CheckOutTime');
         $reg = new Hotel();
         $reg->Name = $Name;
         $reg->NIC = $NIC;
         $reg->Mobile = $Mobile;
         $reg->CheckInTime = $CheckInTime;
         $reg->CheckOutTime = $CheckOutTime;
         $reg->save();
         return redirect('Home');
    }
    function Busbook(Request $req){
         $Name = $req->get('Name');
         $NIC = $req->get('NIC');
         $Mobile = $req->get('Mobile');
         $To = $req->get('To');
         $Form = $req->get('Form');
         $reg = new Bus();
         $reg->Name = $Name;
         $reg->NIC = $NIC;
         $reg->Mobile = $Mobile;
         $reg->To = $To;
         $reg->Form = $Form;
         $reg->save();
         return redirect('Bus');
    }
}

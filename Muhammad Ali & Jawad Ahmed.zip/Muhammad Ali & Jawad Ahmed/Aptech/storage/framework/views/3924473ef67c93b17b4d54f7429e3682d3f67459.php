<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
        <title>Laravel</title>
     </head>
<body>
  <form action="/login" method="get">
  <h1>Login</h1>
    <div class="form-group">
    <label for="exampleInputEmail1">Email</label>
    <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Please Enter Email" name="Email">
    </div>
    <div class="form-group">
    <label for="exampleInputEmail1">Password</label>
    <input type="password" class="form-control" id="exampleInputEmail1" placeholder="Please Enter Password" name="Password">
    <input type="submit" name="submit" value="login">
    </div>
  </form> 
</body>
</html><?php /**PATH F:\Project\Aptech\resources\views/login.blade.php ENDPATH**/ ?>
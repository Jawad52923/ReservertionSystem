<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
        <title>Admin</title>
     </head>
    <body>
    <h1>Hotel Room Detail</h1>
    <table class="table">
    <thead>
        <th>ID</th>
        <th>Name</th>
        <th>NIC</th>
        <th>Mobile</th>
        <th>CheckInTime</th>
        <th>CheckOutTime</th>
    </thead>
    <tbody>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($item['id']); ?></td>
            <td><?php echo e($item['Name']); ?></td>
            <td><?php echo e($item['NIC']); ?></td>
            <td><?php echo e($item['Mobile']); ?></td>
           <td><?php echo e($item['CheckIntime']); ?></td>
            <td><?php echo e($item['CheckOutTime']); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
    </table>
     <h1>Seat Reservetion Detail</h1>
    <table class="table">
    <thead>
        <th>ID</th>
        <th>Name</th>
        <th>NIC</th>
        <th>Mobile</th>
        <th>To</th>
        <th>Form</th>
    </thead>
    <tbody>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($item['id']); ?></td>
            <td><?php echo e($item['Name']); ?></td>
            <td><?php echo e($item['NIC']); ?></td>
            <td><?php echo e($item['Mobile']); ?></td>
            <td><?php echo e($item['To']); ?></td>
            <td><?php echo e($item['Form']); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
    </table>
    </body>
</html>
<?php /**PATH F:\Project\Aptech\resources\views/admin.blade.php ENDPATH**/ ?>
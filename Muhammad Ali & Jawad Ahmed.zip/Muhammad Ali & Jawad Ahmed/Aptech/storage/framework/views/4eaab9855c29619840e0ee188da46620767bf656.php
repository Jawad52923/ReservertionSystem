<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
        <title>Laravel</title>
     </head>
    <body>
<form action="/registration" method="get">
<h1>Registration</h1>
<div class="form-group">
    <label for="exampleInputEmail1">First Name</label>
    <input type="text" class="form-control" id="exampleInputEmail1" placeholder="Enter First Name" name="FName">
  </div>
  <div class="form-group">
    <label for="exampleInputEmail1">Last Name</label>
    <input type="text" class="form-control" id="exampleInputEmail1" placeholder="Enter Last Name" name="LName">
  </div>
  <div class="form-group">
    <label for="exampleInputEmail1">Email address</label>
    <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Please Enter Email" name="Email">
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Password</label>
    <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Please Enter Password" name="Password">
  </div>
  <div class="form-group">
   <select name="user_type" class="form-control">
     <option>Admin</option>
     <option>User</option>

   </select>
  
  </div>
  <input type="submit" name="submit" value="submit">
</form>
<a href="login.blade.php">login</a>
</body>
</html>
<?php /**PATH F:\Project\Aptech\resources\views/registration.blade.php ENDPATH**/ ?>
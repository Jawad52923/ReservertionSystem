<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
        <title>Admin</title>
     </head>
    <body>
    <h1>Hotel Room Detail</h1>
    <table class="table">
    <thead>
        <th>ID</th>
        <th>Name</th>
        <th>NIC</th>
        <th>Mobile</th>
        <th>CheckInTime</th>
        <th>CheckOutTime</th>
    </thead>
    <tbody>
        @foreach ($data as $item)
        <tr>
            <td>{{$item['id']}}</td>
            <td>{{$item['Name']}}</td>
            <td>{{$item['NIC']}}</td>
            <td>{{$item['Mobile']}}</td>
           <td>{{$item['CheckIntime']}}</td>
            <td>{{$item['CheckOutTime']}}</td>
        </tr>
        @endforeach
    </tbody>
    </table>
     <h1>Seat Reservetion Detail</h1>
    <table class="table">
    <thead>
        <th>ID</th>
        <th>Name</th>
        <th>NIC</th>
        <th>Mobile</th>
        <th>To</th>
        <th>Form</th>
    </thead>
    <tbody>
        @foreach ($data as $item)
        <tr>
            <td>{{$item['id']}}</td>
            <td>{{$item['Name']}}</td>
            <td>{{$item['NIC']}}</td>
            <td>{{$item['Mobile']}}</td>
            <td>{{$item['To']}}</td>
            <td>{{$item['Form']}}</td>
        </tr>
        @endforeach
    </tbody>
    </table>
    </body>
</html>

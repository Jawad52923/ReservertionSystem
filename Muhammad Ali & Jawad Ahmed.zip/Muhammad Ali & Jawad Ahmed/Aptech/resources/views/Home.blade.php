<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
        <title>Laravel</title>
     </head>
    <body>
    <form action="/Room" method="get">
    <div class="form-group">
    <label for="exampleInputEmail1">Name</label>
    <input type="text" class="form-control" placeholder="Enter Name" name="Name">
    </div>
    <div class="form-group">
    <label for="exampleInputEmail1">NIC Number</label>
    <input type="text" class="form-control" placeholder="Enter NIC Number" name="NIC">
    </div>  
    <div class="form-group">
    <label for="exampleInputEmail1">Mobile Number</label>
    <input type="text" class="form-control" placeholder="Enter Mobile Number" name="Mobile">
    </div>
    <div class="form-group row">
    <label for="example-datetime-local-input">Check-In-time</label>
    <div class="col-10">
    <input class="form-control" type="datetime-local" value="2011-08-19T13:45:00" id="example-datetime-local-input" name="CheckInTime">
    </div>
    <div class="form-group row">
    <label for="example-datetime-local-input">Check-Out-time</label>
    <div class="col-10">
    <input class="form-control" type="datetime-local" value="2011-08-19T13:45:00" id="example-datetime-local-input" name="CheckOutTime">
    </div>
    <input type="submit" name="Booking" value="Room Bokking">
    </form>                          
    </body>
</html>
